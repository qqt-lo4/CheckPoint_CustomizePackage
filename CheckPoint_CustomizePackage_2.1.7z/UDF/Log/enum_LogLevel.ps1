enum LogLevel {
    Error = 1
    Warning = 2
    Info = 3
    Host = 3
    Verbose = 4
    Debug = 5
}