function Disable-CheckPointEndpointSecurity {
    Param(
        [Parameter(Mandatory)]
        [securestring]$Password,
        [Parameter(Mandatory)]
        [string]$disableToolPath
    )
    
}